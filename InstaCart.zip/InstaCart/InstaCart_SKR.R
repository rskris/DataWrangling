## Author - Srinath K. Ravulaparthy
## Date Completed - 12/20/2018
## Instacart Data Science Challenge

##### STANDARD R-LOADING TEMPLATE ##############
rm(list = ls())
options(scipen = '10')
list.of.packages <-
  c("readr",
    "ggpubr",
    "dplyr",
    "lubridate")
new.packages <-
  list.of.packages[!(list.of.packages %in% installed.packages()[, "Package"])]
if (length(new.packages))
  install.packages(new.packages)
lapply(list.of.packages, require, character = TRUE)
#################################################

path2file <- "C:\\Users\\SrinathRavulaparthy\\Desktop\\InstaCart"
setwd(path2file)

# Read the dataset provided
f0 = readr::read_csv("applicant_data.csv", col_names = TRUE)
print(summary(f0))

# Compute new variables success=1 if event==firt_batch_completed_date, 0 otherwise.
# Convert event_date from m/d/y format to days of the year. E.g. 10/1/2018 will be the 274th day.

f0 = f0 %>% dplyr::mutate(
  success = ifelse(event == "first_batch_completed_date", 1, 0),
  days_year = yday(mdy(event_date))
)


# Aggregate data by applicant_id to investigate the differences in success by control and
# treatment groups.

f1 = f0 %>% group_by(applicant_id, group) %>% summarize(
  success = sum(success),
  min_days = min(days_year),
  max_days = max(days_year)
) %>%
  mutate(ndays = max_days - min_days) %>% select(applicant_id, group, success, ndays)


## Q1. What is the conclusion of A/B testing? A/B test is - initiating background check earlier in the
## hiring process for the treatment group)

# Tabulate the success rate by control & treatment groups

df1 = table(f1$group, f1$success)
colnames(df1) = c("Failure", "Success")
print(df1)

# Compute success rates by control and treatment groups to understand the differences

df2 = f1 %>% group_by(group) %>% summarize(SuccessRate = mean(success),
                                           N = n())
print(df2)

# Two-sample T-test is performed to determine if success rates are the same.
# Alternate hypothesis - Difference in success rates is not equal to 0.

print(t.test(success ~ group, data = f1, conf.level = 0.95))

# Same inference from Wilcox Test which is a non-parametric in nature (Rank Test)
print(wilcox.test(success ~ group, data = f1, conf.level = 0.95))

f1 = f1 %>% mutate(treatment_g = ifelse(group == "treatment", 1, 0))
###m1 = lm(success~treatment_g,data=f1)
###anova(m1)


# A/B testing (earlier background checks in the hiring process) increases success rate in
# treatment group when compared with control group by 73.2%

t1 = 100 * ((df2$SuccessRate[2] / df2$SuccessRate[1]) - 1)

print(paste0("A/B testing increases success rate by ", round(t1, 1), "%"))


## Extension of Q1 to incorporate additional insights

# Summarize applicant data by control and treatment groups to further investigate
# What differences are observed in duration between groups to achieve success?

df3 = f1 %>% group_by(group, success) %>% summarize(avg_days = mean(ndays),
                                                    sd_days = sd(ndays))

print(df3)


f2 = f1 %>% filter(success == 1)
print(t.test(ndays ~ group, data = f2, conf.level = 0.95))

ggboxplot(
  f2,
  x = "group",
  y = "ndays",
  color = "group",
  palette = c("red", "blue"),
  xlab = "Group",
  ylab = "Number of Days to Success"
)

# Build a binary logit model to further investigae the effects of duration and group type
# on likelihood of success.

## Binary Model for Control Group Only.
cdf = f1 %>% filter(group == "control")

f0$city_id = as.numeric(as.factor(f0$city))
f0$social_id = as.numeric(as.factor(f0$channel))

f2 = f0 %>% filter(group == "control") %>% group_by(applicant_id) %>% summarize(city_id = mean(city_id),
                                                                                social_id = mean(social_id)) %>% left_join(cdf, by =
                                                                                                                             c("applicant_id"))

city_dummy = model.matrix(~ factor(f2$city_id))
social_dummy = model.matrix(~ factor(f2$social_id))
colnames(social_dummy) = c("job-search-site",
                           "shopper-referral-bonus",
                           "social-media",
                           "web-search-engine")

# Constants only models
m0 <- lm(success ~ 1, data = cdf, family = binomial(link = "logit"))

# Full Model Specification
m1 <-
  glm(
    success ~ ndays + social_dummy[, "shopper-referral-bonus"] +
      social_dummy[, "web-search-engine"]
    ,
    data = cdf,
    family = binomial(link = "logit")
  )

print("Regression Results for Control Group")

print(summary(m1))

R2 = 1 - (logLik(m1) / logLik(m0))

print(paste("Psuedo R-square for Control Group Model is", round(R2, 2)))


# Binary Model for Treatment Group Only.
tdf = f1 %>% filter(group == "treatment")

f0$city_id = as.numeric(as.factor(f0$city))
f0$social_id = as.numeric(as.factor(f0$channel))

f2 = f0 %>% filter(group == "treatment") %>% group_by(applicant_id) %>% summarize(city_id = mean(city_id),
                                                                                  social_id = mean(social_id)) %>% left_join(tdf, by =
                                                                                                                               c("applicant_id"))
city_dummy = model.matrix(~ factor(f2$city_id))
social_dummy = model.matrix(~ factor(f2$social_id))
colnames(social_dummy) = c("job-search-site",
                           "shopper-referral-bonus",
                           "social-media",
                           "web-search-engine")

# Constants only models
m0 <- lm(success ~ 1, data = tdf, family = binomial(link = "logit"))

# Full Model Specification
m2 <-
  glm(
    success ~ ndays + social_dummy[, "shopper-referral-bonus"] +
      social_dummy[, "web-search-engine"]
    ,
    data = tdf,
    family = binomial(link = "logit")
  )

print("Regression Results for Treatment Group")

print(summary(m2))

R2 = 1 - (logLik(m2) / logLik(m0))

print(paste("Psuedo R-square for Treatment Group Model is", round(R2, 2)))