## Author - Srinath K. Ravulaparthy
## Date Completed - 1/31/2019
## Lumos Labs Data Science Challenge

##### STANDARD R-LOADING TEMPLATE ##############
rm(list = ls())
options(scipen = '10')
list.of.packages <-
  c("tidyverse",
    "readr",
    "data.table",
    "margins",
    "aod")
new.packages <-
  list.of.packages[!(list.of.packages %in% installed.packages()[, "Package"])]
if (length(new.packages))
  install.packages(new.packages)
lapply(list.of.packages, require, character = TRUE)
#################################################

## Part I Q1. To determine the effectiveness of pop-ups within each groups
## The conversion rate or success rate is compared based on Fisher Test.

# Tabulate the Group-A data

mat1 <- matrix(
  c(27, 15, 5528, 2774),
  nrow = 2,
  dimnames = list(
    pop_up = c("Generic", "Snapshot"),
    conversion = c("Yes", "No")
  )
)

addmargins(as.matrix(mat1))

print("Summary of Fisher Exact Test for Group-A Pop-Ups")
fisher.test(mat1, alternative = "less")


# Tablulate Group-B data

mat1 <- matrix(c(2, 4, 3, 593, 576, 598),
               3,
               2,
               dimnames = list(
                 pop_up = c("snapshot", "personalized", "generic"),
                 conversion = c("Yes", "No")
               ))

addmargins(as.matrix(mat1))

print("Summary of Fisher Exact Test for Group-B pop-ups")
fisher.test(mat1, alternative = "less")



## Parth II Q1. Exploratory Data Analysis for error detection in data and cleaning
path2file <- "C:/Users/srina/Downloads/Lumosity"
setwd(path2file)

d1 = readr::read_csv("dataset1.csv", col_names = TRUE)
df1 = d1 %>% dplyr::group_by(user_id) %>% summarize(count = n())
d1 = d1 %>% dplyr::left_join(df1, by = c("user_id")) %>%
  dplyr::filter(count == 1)

d2 = readr::read_csv("dataset2.csv", col_names = TRUE)

d1 = d1 %>% dplyr::left_join(d2, by = c("user_id")) %>% dplyr::select(-c(signup_date))

d3 = readr::read_csv("dataset3.csv", col_names = TRUE)

df2 = d3 %>% dplyr::group_by(user_id) %>% summarize(count = n())
d3 = d3 %>% dplyr::left_join(df2, by = c("user_id")) %>%
  dplyr::filter(count == 1) %>% dplyr::select(-c(mailing_type, send_date))

d4 = d1 %>% dplyr::left_join(d3, by = c("user_id")) %>% dplyr::select(-c(count.x, count.y))

d5 = d4[complete.cases(d4), ]

d5 = d5 %>% dplyr::filter(age <= 100 &
                            num_games_played_3days_after_send < 99999)


#### Q2 Positive effect is defined at a user converting or buying a subscription based on the sent email
#### For this purpose, I use the binary logit modeling framework. The covariate of interest
#### here is whether the email was delivered or not.

m1 <-
  glm(converted ~ delivered,
      data = d5,
      family = binomial(link = "logit"))

# summary of binary logit model
print("Summary of the Binary Logit Model")
print(summary(m1))

# The impact is quantified by marginal effects.
t1 = margins::margins(m1)
print(
  paste0(
    "On an average there is a ",
    100 * round(mean(t1$dydx_delivered), 2),
    "% chance that a user converts or purchases upon an email delivery"
  )
)

### Q3. Mailing type is specified as indicator variables in the logit model to study its impact
### on converted users.

d5 = d5 %>% dplyr::mutate(
  conversion = ifelse(mailing_type == "conversion", 1, 0),
  engagement = ifelse(mailing_type == "engagement", 1, 0)
)

m1 <-
  glm(
    converted ~ conversion + engagement,
    data = d5,
    family = binomial(link = "logit")
  )

# summary of binary logit model
print("Summary of the Binary Logit Model")
print(summary(m1))

# The effectiveness of mailing type is quantified by marginal effects.
# Conversion email is more effective and leads to positive impact than engagement or no-email.
t1 = margins::margins(m1)

print(
  paste0(
    "On an average there is a ",
    100 * round(mean(t1$dydx_conversion), 2),
    "% chance that a user makes a purchase if it is a conversion email"
  )
)

print(
  paste0(
    "On an average there is a ",
    100 * round(mean(t1$dydx_engagement), 3),
    "% chance that a user makes a purchase if it is an engagement email"
  )
)


## The effectiveness is further statistically measured using the Wald Test of parameters

l = cbind(0, 1, -1)
w1 = wald.test(b = coef(m1),
               Sigma = vcov(m1),
               L = l)

print("Summary of Wald Test Results")
summary(w1)


## Q4. Group by analysis to pursue variations in user behavior by demographic segments

d6 = d5 %>% filter(mailing_type != "no_mail")

f1 = d6 %>% dplyr::group_by(mailing_type, gender) %>% summarize(
  count = n(),
  age = median(age),
  purchased = 100 * round(mean(converted), 3),
  performance_index = mean(performance_index),
  ngames_prior_send = mean(num_games_played_3days_prior_send),
  ngames_after_send = mean(num_games_played_3days_after_send)
)


# derive dummy variable for user segments to be used in binary logit models estimated separately
# for conversion and engement emails respectively.
d6 = d6 %>% dplyr::mutate(
  age25 = ifelse(age <= 25, 1, 0),
  age2535 = ifelse(age > 25 & age <= 35, 1, 0),
  age3550 = ifelse(age > 35 & age <= 50, 1, 0),
  age5065 = ifelse(age > 50 & age <= 65, 1, 0),
  age65 = ifelse(age > 65, 1, 0),
  male = ifelse(gender == "m", 1, 0)
)


# binary logit model for Conversion email users.

c1 = d6 %>% filter(mailing_type == "conversion")

m1 <-
  glm(
    converted ~ male + age25 + age2535 + age3550 + age5065,
    data = c1,
    family = binomial(link = "logit")
  )

# summary of binary logit model
print("Summary of the Binary Logit Model for Conversion Users")
print(summary(m1))
print("Marginal Effects of the Logit Model for Conversion Users")
margins::margins(m1)


# binary logit model for Engagement email users.
c1 = d6 %>% filter(mailing_type == "engagement")

m1 <-
  glm(
    converted ~ male + age25 + age2535 + age3550 + age5065,
    data = c1,
    family = binomial(link = "logit")
  )

# summary of binary logit model
print("Summary of the Binary Logit Model for Engagement Users")
print(summary(m1))
print("Marginal Effects of the Logit Model for Engagement Users")
margins::margins(m1)